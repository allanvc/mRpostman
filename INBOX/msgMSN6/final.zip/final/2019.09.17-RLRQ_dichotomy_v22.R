################ Radio-Loud Radio-Quiet dichotomy: a multivariate analysis, Final Version v22  (SEP 17, 2019) ################
## R code to support the statistical analysis for the article
## Allan V. C. Quadros
#rm(list=ls())

# ================ READING AND PREPARING DATASETS AND COLOR PALETTE DEFINITION ================

## ::PALETTE DEFINITION::

library(RColorBrewer)
### visualizing colorBlindFriendly palettes
display.brewer.all(n=NULL,type="qual", colorblindFriendly=TRUE)
### defining
pltte <- brewer.pal(n = 12, name = "Paired")
### picking colors
pos1 <- 2
pos2 <- 8
# pos3 <- 9
# pos3 <- 4
pos3 <- 3


## ::READING THE DATASETS::

dataset1.df <- read.table("data1a.txt", header=TRUE)
dataset2.df <- read.table("data2a.txt", header=TRUE)
dataset3.df <- read.table("data3a.txt", header=TRUE)
dataset4.df <- read.table("data4a.txt", header=TRUE)

#dataset1b.df <- read.table("C:/Users/beaklini/Desktop/P?s-Doc/Projeto_Rafael/Dicotomia/Arquivos_Allan/Parameters_1_RBMRT.txt", header=TRUE)
#dataset2b.df <- read.table("C:/Users/beaklini/Desktop/P?s-Doc/Projeto_Rafael/Dicotomia/Arquivos_Allan/Parameters_2_CBMRT.txt", header=TRUE)
#dataset3b.df <- read.table("C:/Users/beaklini/Desktop/P?s-Doc/Projeto_Rafael/Dicotomia/Arquivos_Allan/Parameters_3_OZVBR.txt", header=TRUE)
#dataset4b.df <- read.table("C:/Users/beaklini/Desktop/P?s-Doc/Projeto_Rafael/Dicotomia/Arquivos_Allan/Parameters_4_RBCFPZ.txt", header=TRUE)


# ================ ANALYSIS KEEPING OUTLIERS ================ #

### eliminating Speak - dataset4
#library(magrittr)
#dataset4.df <- dataset4.df %>% .[,-c(4,6)]

### log transformation to Sint - dataset4
# dataset4.df[,4] <- log(dataset4.df[,4])

## ::ADJUSTING VARIABLE NAMES::

colnames(dataset1.df)[1:4] <- c("Radio", "Optical", "Mass", "R")
colnames(dataset2.df)[1:4] <- c("Radio", "Optical", "Mass", "R") # problem fixed on 09.30.2018
colnames(dataset3.df)[1:4] <- c("Offset","Radio", "Optical", "R")
colnames(dataset4.df)[1:4] <- c("R.band", "B.band", "B.R", "Radio")

### log transformation - dataset 3:
# dataset3.df[,"Radio"] <- log(dataset3.df[,"Radio"]/1000)

### eliminating zeros and -Inf - dataset3:
# row_sub <- apply(dataset3.df, 1, function(row) all( row != 0 && row != -Inf))
# dataset3.df <- dataset3.df[row_sub, ]
# zeroes are measures from offset - we cannot remove it

## ::CREATING FACTOR R>=1 or R<1::

### dataset1

RR1 <- 0.32171
#RR1 <- 0.142248
#RR1 <- -1.35524

RR2 <- 0.381503
#RR2 <- 0.189394
#RR2 <- -0.88890

RR3 <- 0.001896
#RR3 <- 0.001915
#RR3 <- -8.55782


 

dataset1.df$Ratio <- (dataset1.df$R >= RR1)
dataset1.df$Ratio <- ifelse(dataset1.df$Ratio == TRUE, ">RR1", "<RR1")

### dataset2
dataset2.df$Ratio <- (dataset2.df$R >= RR2)
dataset2.df$Ratio <- ifelse(dataset2.df$Ratio == TRUE, ">RR2", "<RR2")

### dataset3
dataset3.df$Ratio <- (dataset3.df$R >= RR3)
dataset3.df$Ratio <- ifelse(dataset3.df$Ratio == TRUE, ">RR3", "<RR3")

# dataset4 ---> no Ratio variable


## ::RUNNING GMM W/ G=2::

library(mclust)
### dataset1
set.seed(1984)
out_dataset1 <- Mclust(dataset1.df[,1:4], G=2)
dataset1.df$Cluster <- as.factor(out_dataset1$classification)
dataset1.df <- cbind(dataset1.df, round(out_dataset1$z,10))

### dataset2
set.seed(1984)
out_dataset2 <- Mclust(dataset2.df[,1:4], G=2)
dataset2.df$Cluster <- as.factor(out_dataset2$classification)
dataset2.df <- cbind(dataset2.df, round(out_dataset2$z,10))

### dataset3
set.seed(1984)
out_dataset3 <- Mclust(dataset3.df[,1:4], G=2)
dataset3.df$Cluster <- as.factor(out_dataset3$classification)
dataset3.df <- cbind(dataset3.df, round(out_dataset3$z,10))

### dataset4
set.seed(1984)
out_dataset4 <- Mclust(dataset4.df[,1:4], G=2)
dataset4.df$Cluster <- as.factor(out_dataset4$classification)
dataset4.df <- cbind(dataset4.df, round(out_dataset4$z,10))


# ================ NEW DATASETS AFTER REMOVING OUTLIERS ================ 

## ::REMOVING THE OUTLIERS::
# above percentile 95% and below peercentile 5%
# but before: remove last column related to previous classification (w/ outliers)

### dataset1
dataset1.dfo <- dataset1.df[,-c((ncol(dataset1.df)-2):ncol(dataset1.df))]
for(j in 1:4){
  quant<-quantile(dataset1.dfo[,j],c(0.05,0.95))
  dataset1.dfo <- dataset1.dfo[dataset1.dfo[,j] >= quant[1] & dataset1.dfo[,j] <= quant[2],]
}

### dataset2
dataset2.dfo <- dataset2.df[,-c((ncol(dataset2.df)-2):ncol(dataset2.df))]
for(j in 1:4){
  quant<-quantile(dataset2.dfo[,j],c(0.05,0.95))
  dataset2.dfo <- dataset2.dfo[dataset2.dfo[,j] >= quant[1] & dataset2.dfo[,j] <= quant[2],]
}

### dataset3
dataset3.dfo <- dataset3.df[,-c((ncol(dataset3.df)-2):ncol(dataset3.df))]
for(j in 1:4){
  quant<-quantile(dataset3.dfo[,j],c(0.05,0.95))
  dataset3.dfo <- dataset3.dfo[dataset3.dfo[,j] >= quant[1] & dataset3.dfo[,j] <= quant[2],]
}

### dataset4
dataset4.dfo <- dataset4.df[,-c((ncol(dataset4.df)-2):ncol(dataset4.df))]
for(j in 1:4){
  quant<-quantile(dataset4.dfo[,j],c(0.05,0.95))
  dataset4.dfo <- dataset4.dfo[dataset4.dfo[,j] >= quant[1] & dataset4.dfo[,j] <= quant[2],]
}


## ::RUNNING GMM W/ G=2::

library(mclust)
### dataset1
set.seed(1984)
out_dataset1o <- Mclust(dataset1.dfo[,1:4], G=2)
dataset1.dfo$Cluster <- as.factor(out_dataset1o$classification)
dataset1.dfo <- cbind(dataset1.dfo, round(out_dataset1o$z,10))

### dataset2
set.seed(1984)
out_dataset2o <- Mclust(dataset2.dfo[,1:4], G=2)
dataset2.dfo$Cluster <- as.factor(out_dataset2o$classification)
dataset2.dfo <- cbind(dataset2.dfo, round(out_dataset2o$z,10))

### dataset3
set.seed(1984)
out_dataset3o <- Mclust(dataset3.dfo[,1:4], G=2)
dataset3.dfo$Cluster <- as.factor(out_dataset3o$classification)
dataset3.dfo <- cbind(dataset3.dfo, round(out_dataset3o$z, 10))

### dataset4
set.seed(1984)
out_dataset4o <- Mclust(dataset4.dfo[,1:4], G=2)
dataset4.dfo$Cluster <- as.factor(out_dataset4o$classification)
dataset4.dfo <- cbind(dataset4.dfo, round(out_dataset4o$z, 10))

# ================ PREPARATION FOR PAIR-WISE PLOTS ================ 

## ::ADJUSTING GROUP LABELS FOR dataset1.dfo and dataset3.dfo (WITHOUT OUTLIERS):

library(dplyr)
### dataset1
dataset1.dfo <- dataset1.dfo %>%
  mutate(Cluster = as.numeric(as.character(Cluster))) %>%
  mutate(Cluster = case_when(Cluster == 1 ~ 3,
                             Cluster == 2 ~ 1, 
                             TRUE ~ 0)) %>%
  mutate(Cluster = case_when(Cluster == 3 ~ 2, 
                             TRUE ~ 1)) %>%
  mutate(Cluster = as.factor(Cluster))
  

### dataset3
dataset3.dfo <- dataset3.dfo %>%
  mutate(Cluster = as.numeric(as.character(Cluster))) %>%
  mutate(Cluster = case_when(Cluster == 1 ~ 3,
                             Cluster == 2 ~ 1, 
                             TRUE ~ 0)) %>%
  mutate(Cluster = case_when(Cluster == 3 ~ 2, 
                             TRUE ~ 1)) %>%
  mutate(Cluster = as.factor(Cluster))


## ::COMBINATORICS STRUCTURE FOR PLOTTING - GETTING THE NAMES::

comb = combn(ncol(dataset1.df[,1:4]),2) # any dataset can be used

### getting variable names correctly - to be used in ggplot graphics
nomes.dataset1 <- colnames(dataset1.df[,1:4])
nomes.dataset2 <- colnames(dataset2.df[,1:4])
nomes.dataset3 <- colnames(dataset3.df[,1:4])
nomes.dataset4 <- colnames(dataset4.df[,1:4])

### structure
comb_nomes <- matrix(NA, nrow=2, ncol=ncol(comb))

### dataset1
comb_nomes.dataset1 <- sapply(1:ncol(comb),function(j){
  sapply(1:2,function(i){
    comb_nomes[i,j]<-nomes.dataset1[comb[i,j]]
  })
})

### dataset2
comb_nomes.dataset2 <- sapply(1:ncol(comb),function(j){
  sapply(1:2,function(i){
    comb_nomes[i,j]<-nomes.dataset2[comb[i,j]]
  })
})

### dataset3
comb_nomes.dataset3 <- sapply(1:ncol(comb),function(j){
  sapply(1:2,function(i){
    comb_nomes[i,j]<-nomes.dataset3[comb[i,j]]
  })
})

### dataset4
comb_nomes.dataset4 <- sapply(1:ncol(comb),function(j){
  sapply(1:2,function(i){
    comb_nomes[i,j]<-nomes.dataset4[comb[i,j]]
  })
})


# ------------- A) PLOTS WITHOUT ELLIPSES ----------

# omitted

# ------------- B) PLOTS WITH ELLIPSES ----------
library(ggplot2)

p <- list()

### dataset1
pe_dataset1 <- sapply(1:length(comb), function(i){
  apply(comb_nomes.dataset1, 2, function(x){
    p[[i]] <- ggplot(dataset1.df, aes_string(x[1], x[2]))+
      geom_point(aes(colour = Cluster, shape=Ratio), size = 2)+
      
      stat_ellipse(geom="polygon", aes(dataset1.df[,x[1]], dataset1.df[,x[2]], color=Cluster,
                                       fill=Cluster), type="norm", level=0.95, alpha = 0.1)+
      stat_ellipse(geom="polygon", aes(dataset1.df[,x[1]], dataset1.df[,x[2]], color=Cluster, fill=Cluster),
                   type="norm", level=0.68, alpha = 0.1)+
      scale_color_manual(values=c(pltte[pos1], pltte[pos2]))+
      scale_fill_manual(values=c(pltte[pos1], pltte[pos2]))+
      theme_bw(base_size = 20)+
      theme(plot.title = element_text(hjust=0.5),
          panel.border = element_blank())+
      coord_fixed(.7)+
      scale_shape_manual(values=c(1, 3), labels = c("R < 1", "R ≥ 1"))+
      guides(colour = guide_legend((override.aes = list())))+
      guides(colour = FALSE)+
      theme(axis.text.x = element_text(size = 15),
            axis.text.y = element_text(size = 15))+
      theme(plot.margin = unit(c(0, 0, 0, 0), "cm"))
  })  
})

# x11()
pe_dataset1[[1]] <- pe_dataset1[[1]]+
  xlab("Radio")+
  ylab("B Band")

pe_dataset1[[2]] <- pe_dataset1[[2]]+
  xlab("Radio")+
  ylab("Mass")

pe_dataset1[[3]] <- pe_dataset1[[3]]+
  xlab("Radio")+
  ylab("R")

pe_dataset1[[4]] <- pe_dataset1[[4]]+
  xlab("B Band")+
  # ylab(expression(Mass ~ "["*M['☉']*"]"))
  ylab("Mass")

pe_dataset1[[5]] <- pe_dataset1[[5]]+
  ylab("B Band")+
  ylab("R")

pe_dataset1[[6]] <- pe_dataset1[[6]]+
  xlab("Mass")+
  ylab("R")


### without outliers
pe_dataset1o <- sapply(1:length(comb), function(i){
  apply(comb_nomes.dataset1, 2, function(x){
    p[[i]] <- ggplot(dataset1.dfo, aes_string(x[1], x[2]))+
      geom_point(aes(colour = Cluster, shape=Ratio), size = 2)+
      
      stat_ellipse(geom="polygon", aes(dataset1.dfo[,x[1]], dataset1.dfo[,x[2]], color=Cluster,
                                       fill=Cluster), type="norm", level=0.95, alpha = 0.1)+
      stat_ellipse(geom="polygon", aes(dataset1.dfo[,x[1]], dataset1.dfo[,x[2]], color=Cluster, fill=Cluster),
                   type="norm", level=0.68, alpha = 0.1)+
      scale_color_manual(values=c(pltte[pos1], pltte[pos2]))+
      scale_fill_manual(values=c(pltte[pos1], pltte[pos2]))+
      theme_bw(base_size = 20)+
      theme(plot.title = element_text(hjust=0.5),
          panel.border = element_blank())+
      coord_fixed(0.7)+
      scale_shape_manual(values=c(1, 3), labels = c("R < 1", "R ≥ 1"))+
      guides(colour = guide_legend((override.aes = list())))+
      guides(colour = FALSE)+
      theme(axis.text.x = element_text(size = 15),
            axis.text.y = element_text(size = 15))+
      theme(plot.margin = unit(c(0, 0, 0, 0), "cm"))
  })  
})
# x11()
pe_dataset1o[[1]] <- pe_dataset1o[[1]]+
  xlab("Radio")+
  ylab("B Band")

pe_dataset1o[[2]] <- pe_dataset1o[[2]]+
  xlab("Radio")+
  ylab("Mass")
  
pe_dataset1o[[3]] <- pe_dataset1o[[3]]+
  xlab("Radio")+
  ylab("R")

pe_dataset1o[[4]] <- pe_dataset1o[[4]]+
  xlab("B Band")+
  ylab("Mass")
  #ylab(expression(log *" "* Mass *" "* "["*M['\u2609'] * "]"))

pe_dataset1o[[5]] <- pe_dataset1o[[5]]+
  xlab("B Band")+
  ylab("R")

pe_dataset1o[[6]] <- pe_dataset1o[[6]]+
  xlab("Mass")+
  ylab("R")

#### plot
### dataset1

library(cowplot)
# arrange plots in two rows
pegrid1 <- plot_grid( pe_dataset1[[1]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset1[[2]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset1[[3]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset1[[4]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset1[[5]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset1[[6]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset1o[[1]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset1o[[2]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset1o[[3]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset1o[[4]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset1o[[5]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset1o[[6]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      align = 'vh',
                      nrow = 2
)


# add the legend to the row we made earlier. Give it one-third of the width
# of one plot (via rel_widths).
legend <- get_legend(pe_dataset1[[3]])
# warnings() -- about greater than/equal sign

pegrid_dataset1 <- plot_grid(pegrid1, legend, rel_widths = c(3, .4))

# pegrid_dataset1 <- plot_grid(pegrid1, legend, rel_widths = c(10, .2))

# pegrid_dataset1 <- plot_grid(pegrid1)

# x11()
pegrid_dataset1
# soh interessa depois que salva

# save_plot can be a nice way to set the aspect_ratio...play with these options
save_plot("./fig/dataset1.svg", pegrid_dataset1, dpi=500,
          ncol = 7, # we're saving a grid plot of 2 columns
          nrow = 2, # and 2 rows
          # each individual subplot should have an aspect ratio of 1.3
          base_aspect_ratio = 1
)



### dataset2
pe_dataset2 <- sapply(1:length(comb), function(i){
  apply(comb_nomes.dataset2, 2, function(x){
    p[[i]] <- ggplot(dataset2.df, aes_string(x[1], x[2]))+
      geom_point(aes(colour = Cluster, shape=Ratio), size = 2)+
      
      stat_ellipse(geom="polygon", aes(dataset2.df[,x[1]], dataset2.df[,x[2]], color=Cluster,
                                       fill=Cluster), type="norm", level=0.95, alpha = 0.1)+
      stat_ellipse(geom="polygon", aes(dataset2.df[,x[1]], dataset2.df[,x[2]], color=Cluster, fill=Cluster),
                   type="norm", level=0.68, alpha = 0.1)+
      scale_color_manual(values=c(pltte[pos1], pltte[pos2]))+
      scale_fill_manual(values=c(pltte[pos1], pltte[pos2]))+
      theme_bw(base_size = 20)+
      theme(plot.title = element_text(hjust=0.5),
            panel.border = element_blank())+
      coord_fixed(0.56)+
      scale_shape_manual(values=c(1, 3), labels = c("R < 1", "R ≥ 1"))+
      guides(colour = guide_legend((override.aes = list())))+
      guides(colour = FALSE)
    
  })  
})

# x11()
pe_dataset2[[1]] <- pe_dataset2[[1]]+
  xlab("Radio")+
  ylab("B Band")

pe_dataset2[[2]] <- pe_dataset2[[2]]+
  xlab("Radio")+
  # ylab(expression(Mass ~ "["*M['☉']*"]"))
  ylab("Mass")

pe_dataset2[[3]] <- pe_dataset2[[3]]+
  xlab("Radio")+
  ylab("R")

pe_dataset2[[4]] <- pe_dataset2[[4]]+
  xlab("B Band")+
  # ylab(expression(Mass ~ "["*M['☉']*"]"))
  ylab("Mass")

pe_dataset2[[5]] <- pe_dataset2[[5]]+
  xlab("B Band")+
  ylab("R")

pe_dataset2[[6]] <- pe_dataset2[[6]]+
  xlab("Mass")+
  #xlab(expression(log *" "* Mass *" "* "["*M['\u2609'] * "]"))+
  ylab("R")


### without outliers
pe_dataset2o <- sapply(1:length(comb), function(i){
  apply(comb_nomes.dataset2, 2, function(x){
    p[[i]] <- ggplot(dataset2.dfo, aes_string(x[1], x[2]))+
      geom_point(aes(colour = Cluster, shape=Ratio), size = 2)+
      
      stat_ellipse(geom="polygon", aes(dataset2.dfo[,x[1]], dataset2.dfo[,x[2]], color=Cluster,
                                       fill=Cluster), type="norm", level=0.95, alpha = 0.1)+
      stat_ellipse(geom="polygon", aes(dataset2.dfo[,x[1]], dataset2.dfo[,x[2]], color=Cluster, fill=Cluster),
                   type="norm", level=0.68, alpha = 0.1)+
      scale_color_manual(values=c(pltte[pos1], pltte[pos2]))+
      scale_fill_manual(values=c(pltte[pos1], pltte[pos2]))+
      theme_bw(base_size = 20)+
      theme(plot.title = element_text(hjust=0.5),
            panel.border = element_blank())+
      coord_fixed(0.56)+
      scale_shape_manual(values=c(1, 3), labels = c("R < 1", "R ≥ 1"))+
      guides(colour = guide_legend((override.aes = list())))+
      guides(colour = FALSE)
    
  })  
})

# x11()
pe_dataset2o[[1]] <- pe_dataset2o[[1]]+
  xlab("Radio")+
  ylab("B Band")

pe_dataset2o[[2]] <- pe_dataset2o[[2]]+
  xlab("Radio")+
  # ylab(expression(Mass ~ "["*M['☉']*"]"))
  ylab("Mass")

pe_dataset2o[[3]] <- pe_dataset2o[[3]]+
  xlab("Radio")+
  ylab("R")

pe_dataset2o[[4]] <- pe_dataset2o[[4]]+
  xlab("B Band")+
  # ylab(expression(Mass ~ "["*M['☉']*"]"))
  ylab("Mass")

pe_dataset2o[[5]] <- pe_dataset2o[[5]]+
  xlab("B Band")+
  ylab("R")

pe_dataset2o[[6]] <- pe_dataset2o[[6]]+
  # xlab(expression(Mass ~ "["*M['☉']*"]"))
  xlab("Mass")+
  ylab("R")

#### plot
### dataset2

library(cowplot)
# arrange plots in two rows
pegrid2 <- plot_grid( pe_dataset2[[1]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset2[[2]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset2[[3]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset2[[4]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset2[[5]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset2[[6]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset2o[[1]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset2o[[2]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset2o[[3]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset2o[[4]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset2o[[5]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset2o[[6]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      align = 'vh',
                      nrow = 2
)

# add the legend to the row we made earlier. Give it one-third of the width
# of one plot (via rel_widths).
legend <- get_legend(pe_dataset2[[3]])
# warnings() -- about greater than/equal sign

pegrid_dataset2 <- plot_grid(pegrid2, legend, rel_widths = c(3, .4))

# pegrid_dataset2 <- plot_grid(pegrid1, legend, rel_widths = c(10, .2))

# pegrid_dataset2 <- plot_grid(pegrid1)

# x11()
pegrid_dataset2
# soh interessa depois que salva

# save_plot can be a nice way to set the aspect_ratio...play with these options
save_plot("./fig/dataset2.svg", pegrid_dataset2, dpi=500,
          ncol = 7, # we're saving a grid plot of 2 columns
          nrow = 2, # and 2 rows
          # each individual subplot should have an aspect ratio of 1.3
          base_aspect_ratio = 1
)


### dataset3
pe_dataset3 <- sapply(1:length(comb), function(i){
  apply(comb_nomes.dataset3, 2, function(x){
    p[[i]] <- ggplot(dataset3.df, aes_string(x[1], x[2]))+
      geom_point(aes(colour = Cluster, shape=Ratio), size = 2)+
      
	stat_ellipse(geom="polygon", aes(dataset3.df[,x[1]], dataset3.df[,x[2]], color=Cluster,
                                        fill=Cluster), type="norm", level=0.95, alpha = 0.1)+
      stat_ellipse(geom="polygon", aes(dataset3.df[,x[1]], dataset3.df[,x[2]], color=Cluster, fill=Cluster),
                    type="norm", level=0.68, alpha = 0.1)+
      scale_color_manual(values=c(pltte[pos1], pltte[pos2]))+
      scale_fill_manual(values=c(pltte[pos1], pltte[pos2]))+
      theme_bw(base_size = 20)+
      theme(plot.title = element_text(hjust=0.5),
            panel.border = element_blank())+
      coord_fixed(0.5)+
      scale_shape_manual(values=c(1, 3), labels = c("R < 1", "R ≥ 1"))+
      guides(colour = guide_legend((override.aes = list())))+
      guides(colour = FALSE)+
      # theme(axis.text.x = element_text(size = 11, angle = 45),
      #       axis.text.y = element_text(size = 11, angle = 45))
      theme(axis.text.x = element_text(size = 15),
            axis.text.y = element_text(size = 15))
      
  })  
})

# x11()
library(scales)
# scientific_10 <- function(x) {
#   parse(text=gsub("e", " %*% 10^", scales::scientific_format()(x)))
# }

scientific_10 <- function(x) {
  # parse(text=gsub("e", " %*% 10^", scales::scientific_format()(x)))
  ifelse(x==0, "0", parse(text=gsub("[+]", "", gsub("e", " %*% 10^", scientific_format()(x)))))
}


library(scales)


pe_dataset3[[1]] <- pe_dataset3[[1]]+
  #aes(x=Offset, y=Radio)+
  xlab("Offset")+
  ylab("Radio")

pe_dataset3[[2]] <- pe_dataset3[[2]]+
  xlab("Offset")+
  ylab("B Band")


pe_dataset3[[3]] <- pe_dataset3[[3]]+
  xlab("Offset")+
  ylab("R")

pe_dataset3[[4]] <- pe_dataset3[[4]]+
  xlab("Radio")+
  ylab("B Band")+
  scale_x_continuous(breaks= seq(0.0,0.9, by = 0.3))


pe_dataset3[[5]] <- pe_dataset3[[5]]+
  xlab("Radio")+
  ylab("R")+
  scale_x_continuous(breaks= seq(0.0,0.9, by = 0.3))

pe_dataset3[[6]] <- pe_dataset3[[6]]+
  xlab("B Band")+
  ylab("R")
  
### without outliers
pe_dataset3o <- sapply(1:length(comb), function(i){
  apply(comb_nomes.dataset3, 2, function(x){
    p[[i]] <- ggplot(dataset3.dfo, aes_string(x[1], x[2]))+
      geom_point(aes(colour = Cluster, shape=Ratio), size = 2)+
      
      stat_ellipse(geom="polygon", aes(dataset3.dfo[,x[1]], dataset3.dfo[,x[2]], color=Cluster,
                                        fill=Cluster), type="norm", level=0.95, alpha = 0.1)+
      stat_ellipse(geom="polygon", aes(dataset3.dfo[,x[1]], dataset3.dfo[,x[2]], color=Cluster, fill=Cluster),
                    type="norm", level=0.68, alpha = 0.1)+
      scale_color_manual(values=c(pltte[pos1], pltte[pos2]))+
      scale_fill_manual(values=c(pltte[pos1], pltte[pos2]))+
      theme_bw(base_size = 20)+
      theme(plot.title = element_text(hjust=0.5),
            panel.border = element_blank())+
      coord_fixed(0.5)+
      scale_shape_manual(values=c(1, 3), labels = c("R < 1", "R ≥ 1"))+
      guides(colour = guide_legend((override.aes = list())))+
      guides(colour = FALSE)+
      # theme(axis.text.x = element_text(size = 11, angle = 45),
      #       axis.text.y = element_text(size = 11, angle = 45))
      theme(axis.text.x = element_text(size = 15),
            axis.text.y = element_text(size = 15))
  })  
})

library(scales)
# x11()
pe_dataset3o[[1]] <- pe_dataset3o[[1]]+
  xlab("Offset")+
  ylab("Radio")

pe_dataset3o[[2]] <- pe_dataset3o[[2]]+
  xlab("Offset")+
  ylab("B Band")

pe_dataset3o[[3]] <- pe_dataset3o[[3]]+
  xlab("Offset")+
  ylab("R")

pe_dataset3o[[4]] <- pe_dataset3o[[4]]+
  xlab("Radio")+
  ylab("B Band")+
  scale_x_continuous(breaks= c(0.2, 0.4))

pe_dataset3o[[5]] <- pe_dataset3o[[5]]+
  xlab("Radio")+
  ylab("R")+
  scale_x_continuous(breaks= c(0.2, 0.4))

pe_dataset3o[[6]] <- pe_dataset3o[[6]]+
  xlab("B Band")+
  ylab("R")


#### plot
### dataset3

library(cowplot)
# arrange plots in two rows
pegrid3 <- plot_grid( pe_dataset3[[1]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset3[[2]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset3[[3]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset3[[4]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset3[[5]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset3[[6]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset3o[[1]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset3o[[2]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset3o[[3]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset3o[[4]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset3o[[5]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset3o[[6]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      align = 'vh',
                      nrow = 2
)

# add the legend to the row we made earlier. Give it one-third of the width
# of one plot (via rel_widths).
legend <- get_legend(pe_dataset3[[3]])
# warnings() -- about greater than/equal sign

pegrid_dataset3 <- plot_grid(pegrid3, legend, rel_widths = c(3, .4))

# pegrid_dataset3 <- plot_grid(pegrid1, legend, rel_widths = c(10, .2))

# pegrid_dataset3 <- plot_grid(pegrid1)

# x11()
pegrid_dataset3
# soh interessa depois que salva

# save_plot can be a nice way to set the aspect_ratio...play with these options
save_plot("./fig/dataset3.svg", pegrid_dataset3, dpi=500,
          ncol = 7, # we're saving a grid plot of 2 columns
          nrow = 2, # and 2 rows
          # each individual subplot should have an aspect ratio of 1.3
          base_aspect_ratio = 1
)


### dataset4
pe_dataset4 <- sapply(1:length(comb), function(i){
  apply(comb_nomes.dataset4, 2, function(x){
    p[[i]] <- ggplot(dataset4.df, aes_string(x[1], x[2]))+
      geom_point(aes(colour = Cluster), size = 2, shape = 1)+
      
      stat_ellipse(geom="polygon", aes(dataset4.df[,x[1]], dataset4.df[,x[2]], color=Cluster,
                                        fill=Cluster), type="norm", level=0.95, alpha = 0.1)+
      stat_ellipse(geom="polygon", aes(dataset4.df[,x[1]], dataset4.df[,x[2]], color=Cluster, fill=Cluster),
                    type="norm", level=0.68, alpha = 0.1)+
      scale_color_manual(values=c(pltte[pos1], pltte[pos2]))+
      scale_fill_manual(values=c(pltte[pos1], pltte[pos2]))+
      theme_bw(base_size = 20)+
      theme(plot.title = element_text(hjust=0.5),
            panel.border = element_blank())+
      
      xlab(
        ifelse(gsub("_", " ",x[1]) == x[1], 
               gsub("\\.", "-",x[1]),
               gsub("_", " ",x[1]))
      )+
      
      ylab(
        ifelse(gsub("_", " ",x[2]) == x[2],
               gsub("\\.", "-",x[2]),
               gsub("_", " ",x[2]))
      )+
      coord_fixed(0.23)+
      guides(colour = guide_legend((override.aes = list())))+
      guides(colour = FALSE)+
      # theme(axis.text.x = element_text(size = 11, angle = 45),
      #       axis.text.y = element_text(size = 11, angle = 45))
      theme(axis.text.x = element_text(size = 15),
            axis.text.y = element_text(size = 15))
  })  
})

# x11()
pe_dataset4[[1]] <- pe_dataset4[[1]]+
  xlab("R Band")+
  ylab("B Band")

pe_dataset4[[2]] <- pe_dataset4[[2]]+
  xlab("R Band")+
  ylab("B-R")

pe_dataset4[[3]] <- pe_dataset4[[3]]+
  xlab("R Band")+
  ylab("Radio")

pe_dataset4[[4]] <- pe_dataset4[[4]]+
  xlab("B Band")+
  ylab("B-R")

pe_dataset4[[5]] <- pe_dataset4[[5]]+
  ylab("B Band")+
  xlab("Radio")

pe_dataset4[[6]] <- pe_dataset4[[6]]+
  #aes(x=Radio, y=B.R)+
  ylab("B-R")+
  xlab("Radio")


### without outliers
pe_dataset4o <- sapply(1:length(comb), function(i){
  apply(comb_nomes.dataset4, 2, function(x){
    p[[i]] <- ggplot(dataset4.dfo, aes_string(x[1], x[2]))+
      geom_point(aes(colour = Cluster), size = 2, shape = 1)+
      
      stat_ellipse(geom="polygon", aes(dataset4.dfo[,x[1]], dataset4.dfo[,x[2]], color=Cluster,
                                        fill=Cluster), type="norm", level=0.95, alpha = 0.1)+
      stat_ellipse(geom="polygon", aes(dataset4.dfo[,x[1]], dataset4.dfo[,x[2]], color=Cluster, fill=Cluster),
                    type="norm", level=0.68, alpha = 0.1)+
      scale_color_manual(values=c(pltte[pos1], pltte[pos2]))+
      scale_fill_manual(values=c(pltte[pos1], pltte[pos2]))+
      theme_bw(base_size = 20)+
      theme(plot.title = element_text(hjust=0.5),
            panel.border = element_blank())+
      # no legend because we have no R > < 1
      
      xlab(
        ifelse(gsub("_", " ",x[1]) == x[1], 
               gsub("\\.", "-",x[1]),
               gsub("_", " ",x[1]))
      )+
      
      ylab(
        ifelse(gsub("_", " ",x[2]) == x[2],
               gsub("\\.", "-",x[2]),
               gsub("_", " ",x[2]))
      )+
      coord_fixed(0.23)+
      guides(colour = guide_legend((override.aes = list())))+
      guides(colour = FALSE)+
      # theme(axis.text.x = element_text(size = 11, angle = 45),
      #       axis.text.y = element_text(size = 11, angle = 45))
      theme(axis.text.x = element_text(size = 15),
            axis.text.y = element_text(size = 15))
  })  
})

# x11()
pe_dataset4o[[1]] <- pe_dataset4o[[1]]+
  xlab("R Band")+
  ylab("B Band")

pe_dataset4o[[2]] <- pe_dataset4o[[2]]+
  xlab("R Band")+
  ylab("B-R")

pe_dataset4o[[3]] <- pe_dataset4o[[3]]+
  xlab("R Band")+
  ylab("Radio")

pe_dataset4o[[4]] <- pe_dataset4o[[4]]+
  xlab("B Band")+
  ylab("B-R")

pe_dataset4o[[5]] <- pe_dataset4o[[5]]+
  #aes(x=Radio, y=B.band)+
  ylab("B Band")+
  xlab("Radio")

pe_dataset4o[[6]] <- pe_dataset4o[[6]]+
  #aes(x=Radio, y=B.R)+
  ylab("B-R")+
  xlab("Radio")

#### plot
### dataset4

library(cowplot)
# arrange plots in two rows
pegrid4 <- plot_grid( pe_dataset4[[1]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset4[[2]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset4[[3]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset4[[4]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset4[[5]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset4[[6]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset4o[[1]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset4o[[2]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset4o[[3]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset4o[[4]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset4o[[5]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      pe_dataset4o[[6]] + theme(legend.position="none", plot.margin = unit(c(0, 0, 0, 0), "cm")),
                      align = 'vh',
                      nrow = 2
)

# add the legend to the row we made earlier. Give it one-third of the width
# of one plot (via rel_widths).
legend <- get_legend(pe_dataset4[[3]])
# warnings() -- about greater than/equal sign

pegrid_dataset4 <- plot_grid(pegrid4, legend, rel_widths = c(3, .4))

# pegrid_dataset4 <- plot_grid(pegrid1, legend, rel_widths = c(10, .2))

# pegrid_dataset4 <- plot_grid(pegrid1)

# x11()
pegrid_dataset4
# soh interessa depois que salva

# save_plot can be a nice way to set the aspect_ratio...play with these options
save_plot("./fig/dataset4.svg", pegrid_dataset4, dpi=500,
          ncol = 7, # we're saving a grid plot of 2 columns
          nrow = 2, # and 2 rows
          # each individual subplot should have an aspect ratio of 1.3
          base_aspect_ratio = 1
)


# ================ Z SCORES - PROBABILITY OF MEMBERSHIP TO EACH CLUSTER ================
# package hexbin needed
# install.packages("hexbin")

### dataset1
p_dataset1_prob <- ggplot(dataset1.df, aes(Radio, Optical))+
  stat_summary_hex(aes(z = out_dataset1$z[,1]))+
  scale_fill_gradientn (colors = c(pltte[pos2], pltte[pos3], pltte[pos1]),
                        labels=c('','group 1',0.5,'group 2', ''))+ # we needed to revert colors
  ggtitle("Dataset 1")+
  theme_bw(base_size = 20)+
  theme(plot.title = element_text(hjust=0.5))+
  labs(fill='Probability')+ # changing legend title
  coord_fixed()+
  xlab("Radio")+
  ylab("B Band")

### dataset2
p_dataset2_prob <- ggplot(dataset2.df, aes(Radio, Optical))+
  stat_summary_hex(aes(z = out_dataset2$z[,1]))+
  scale_fill_gradientn (colors = c(pltte[pos2], pltte[pos3], pltte[pos1]),
                        labels=c('','group 1',0.5,'group 2', ''))+ # we needed to revert colors
  # scale_fill_viridis(option = viridis.vec[vir.opt], labels=c('','group 2',0.5,'group 1', ''))+
  ggtitle("Dataset 2")+
  theme_bw(base_size = 20)+
  theme(plot.title = element_text(hjust=0.5))+
  labs(fill='Probability')+
  coord_fixed()+
  xlab("Radio")+
  ylab("B Band")

### dataset3
p_dataset3_prob <- ggplot(dataset3.df, aes(Radio, Optical))+
  stat_summary_hex(aes(z = out_dataset3$z[,1]))+
  scale_fill_gradientn (colors = c(pltte[pos2], pltte[pos3], pltte[pos1]),
                        labels=c('','group 1',0.5,'group 2', ''))+ # we needed to revert colors
  ggtitle("Dataset 3")+
  theme_bw(base_size = 20)+
  theme(plot.title = element_text(hjust=0.5))+
  labs(fill='Probability')+
  coord_fixed()+
  xlab("Radio")+
  ylab("B Band")
  #theme(axis.text.x = element_text(size = 11, angle = 30))+
  # theme(axis.text.x = element_text(size = 13))+
  #scale_x_continuous(trans='log10', labels = scientific_10) #+
  

### dataset4 (removing outliers - only for dataset4)
p_dataset4_prob <- ggplot(dataset4.dfo, aes(Radio, B.band))+ # returning B.band to y.axis
  stat_summary_hex(aes(z = out_dataset4o$z[,1]))+
  scale_fill_gradientn (colors = c(pltte[pos2], pltte[pos3], pltte[pos1]),
                        labels=c('','group 1',0.5,'group 2', ''))+ # we needed to revert colors
  ggtitle("Dataset 4")+
  theme_bw(base_size = 20)+
  theme(plot.title = element_text(hjust=0.5))+
  labs(fill='Probability')+
  coord_fixed(ratio = 0.4)+
  ylab("B Band")+
  xlab("Radio")
  #theme(axis.text.x = element_text(size = 14))+
  #scale_x_continuous(trans='log10', labels = scientific_10) #+
  
  
  
## ::GRID PLOT::
library(cowplot)

# arrange plots in one row
pprobgrid <- plot_grid( p_dataset1_prob + theme(legend.position="none"),
                     p_dataset2_prob + theme(legend.position="none"),
                     p_dataset3_prob + theme(legend.position="none"),
                     p_dataset4_prob + theme(legend.position="none"),
                     align = 'vh',
                     nrow = 1
)

# add the legend to the row we made earlier. Give it one-third of the width
# of one plot (via rel_widths).
# legend <- get_legend(p_dataset1_prob + theme(legend.position=c(-0.7,0.5)))
legend <- get_legend(p_dataset1_prob)

pgrid_prob <- plot_grid(pprobgrid, legend, rel_widths = c(3, .3))

#x11()
pgrid_prob


# save_plot can be a nice way to set the aspect_ratio...play with these options
save_plot("./fig/prob_plot.svg", pgrid_prob, dpi=500,
          ncol = 4, # we're saving a grid plot of 2 columns
          nrow = 1, # and 2 rows
          # each individual subplot should have an aspect ratio of 1.3
          base_aspect_ratio = 1
)



# ================ GMM WITH G=3 ================ 
library(mclust)

### dataset1
set.seed(1984)
out_dataset1_3g <- Mclust(dataset1.df[,1:4], G=3)
dataset1.df$Cluster_3G <- as.factor(out_dataset1_3g$classification)

### dataset2
set.seed(1984)
out_dataset2_3g <- Mclust(dataset2.df[,1:4], G=3)
dataset2.df$Cluster_3G <- as.factor(out_dataset2_3g$classification)

### dataset3
set.seed(1984)
out_dataset3_3g <- Mclust(dataset3.df[,1:4], G=3)
dataset3.df$Cluster_3G <- as.factor(out_dataset3_3g$classification)

### dataset4 (without outliers)
set.seed(1984)
out_dataset4o_3g <- Mclust(dataset4.dfo[,1:4], G=3)
dataset4.dfo$Cluster_3G <- as.factor(out_dataset4o_3g$classification)

### reversing clusters numbers in dataset4.dfo
dataset4.dfo <- dataset4.dfo %>%
  mutate(Cluster_3G = as.numeric(as.character(Cluster_3G))) %>%
  mutate(Cluster_3G = case_when(Cluster_3G == 1 ~ 4,
                             Cluster_3G == 3 ~ 1, 
                             TRUE ~ 2)) %>%
  mutate(Cluster_3G = case_when(Cluster_3G == 4 ~ 3, 
                                Cluster_3G == 1 ~ 1, 
                                TRUE ~ 2)) %>%
  mutate(Cluster_3G = as.factor(Cluster_3G))


## ::3G PLOTS WITH ELLIPSES::

### dataset1
pe_dataset1_3g <- ggplot(dataset1.df, aes(Radio, Optical))+
  geom_point(aes(colour = Cluster_3G, shape=Ratio), size = 2, alpha = 0.8)+
  stat_ellipse(geom="polygon", aes(Radio, Optical, color=Cluster_3G,
                                   fill=Cluster_3G), type="norm", level=0.95, alpha = 0.3)+
  stat_ellipse(geom="polygon", aes(Radio, Optical, color=Cluster_3G, fill=Cluster_3G),
               type="norm", level=0.68, alpha = 0.3)+
  scale_color_manual(values=c(pltte[pos1], pltte[pos2], pltte[pos3]))+
  scale_fill_manual(values=c(pltte[pos1], pltte[pos2], pltte[pos3]))+
  theme_bw(base_size = 20)+
  theme(plot.title = element_text(hjust=0.5),
        panel.border = element_blank())+
  coord_fixed(0.8)+
  ggtitle("Dataset 1")+
  scale_shape_manual(values=c(1, 3), labels = c("R < 1", "R > 1"))+
  guides(color=guide_legend(title="Cluster"),
         fill=guide_legend(title="Cluster"))+ # we need to change fill and color legends
  guides(colour = guide_legend((override.aes = list())))+
  guides(colour = FALSE)+
  xlab("Radio")+
  ylab("B Band") #+
  # guides(fill = FALSE)
  # guides(shape = FALSE)

### dataset2
pe_dataset2_3g <- ggplot(dataset2.df, aes(Radio, Optical))+
  geom_point(aes(colour = Cluster_3G, shape=Ratio), size = 2, alpha = 0.8)+
  stat_ellipse(geom="polygon", aes(Radio, Optical, color=Cluster_3G,
                                   fill=Cluster_3G), type="norm", level=0.95, alpha = 0.3)+
  stat_ellipse(geom="polygon", aes(Radio, Optical, color=Cluster_3G, fill=Cluster_3G),
               type="norm", level=0.68, alpha = 0.3)+
  scale_color_manual(values=c(pltte[pos1], pltte[pos2], pltte[pos3]))+
  scale_fill_manual(values=c(pltte[pos1], pltte[pos2], pltte[pos3]))+
  theme_bw(base_size = 20)+
  theme(plot.title = element_text(hjust=0.5),
        panel.border = element_blank())+
  coord_fixed(0.8)+
  ggtitle("Dataset 2")+
  scale_shape_manual(values=c(1, 3), labels = c("R < 1", "R > 1"))+
  guides(color=guide_legend(title="Cluster"),
         fill=guide_legend(title="Cluster"))+ # we need to change fill and color legends
  guides(colour = guide_legend((override.aes = list())))+
  guides(colour = FALSE)+ # we need to change fill and color legends
  xlab("Radio")+
  ylab("B Band") #+
  # guides(fill = FALSE)
  # guides(shape = FALSE)


### dataset3
pe_dataset3_3g <- ggplot(dataset3.df, aes(Radio, Optical))+
  geom_point(aes(colour = Cluster_3G, shape=Ratio), size = 2, alpha = 0.8)+
  stat_ellipse(geom="polygon", aes(Radio, Optical, color=Cluster_3G,
                                   fill=Cluster_3G), type="norm", level=0.95, alpha = 0.3)+
  stat_ellipse(geom="polygon", aes(Radio, Optical, color=Cluster_3G, fill=Cluster_3G),
               type="norm", level=0.68, alpha = 0.3)+
  scale_color_manual(values=c(pltte[pos1], pltte[pos2], pltte[pos3]))+
  scale_fill_manual(values=c(pltte[pos1], pltte[pos2], pltte[pos3]))+
  theme_bw(base_size = 20)+
  theme(plot.title = element_text(hjust=0.5),
        panel.border = element_blank())+
  coord_fixed(0.2)+
  ggtitle("Dataset 3")+
  scale_shape_manual(values=c(1, 3), labels = c("R < 1", "R > 1"))+
  guides(color=guide_legend(title="Cluster"),
         fill=guide_legend(title="Cluster"))+ # we need to change fill and color legends
  guides(colour = guide_legend((override.aes = list())))+
  guides(colour = FALSE)+ # we need to change fill and color legends
  xlab("Radio")+
  ylab("B Band")
  #theme(axis.text.x = element_text(size = 12, angle = 40))+
  #scale_x_continuous(trans='log10', labels = scientific_10) #+

  # guides(fill = FALSE)
  # guides(shape = FALSE)

### dataset4 (removing outliers)
pe_dataset4o_3g <- ggplot(dataset4.dfo, aes(Radio, B.band))+
  geom_point(aes(colour = Cluster_3G), size = 2, shape=1, alpha = 0.8)+
  stat_ellipse(geom="polygon", aes(Radio, B.band, color=Cluster_3G,
                                   fill=Cluster_3G), type="norm", level=0.95, alpha = 0.3)+
  stat_ellipse(geom="polygon", aes(Radio, B.band, color=Cluster_3G, fill=Cluster_3G),
               type="norm", level=0.68, alpha = 0.3)+
  scale_color_manual(values=c(pltte[pos1], pltte[pos2], pltte[pos3]))+
  scale_fill_manual(values=c(pltte[pos1], pltte[pos2], pltte[pos3]))+
  # scale_x_continuous(breaks = seq(1.21, 1.29, by = .02))+
  theme_bw(base_size = 20)+
  theme(plot.title = element_text(hjust=0.5),
        panel.border = element_blank())+
  coord_fixed(0.4)+
  ggtitle("Dataset 4")+
  xlab("B Band")+
  guides(color=guide_legend(title="Cluster"),
         fill=guide_legend(title="Cluster"))+ # we need to change fill and color legends
  guides(colour = guide_legend((override.aes = list())))+
  guides(colour = FALSE)+ # we need to change fill and color legends
  ylab("B Band")+
  xlab("Radio")
  #theme(axis.text.x = element_text(size = 12, angle = 40))+
  #scale_x_continuous(trans='log10', labels = scientific_10) #+

## ::GRID PLOT::
library(cowplot)

# arrange plots in one row
perow_3g <- plot_grid( pe_dataset1_3g +guides(fill = FALSE) +theme(legend.position="none"),
                        pe_dataset2_3g +guides(fill = FALSE) +theme(legend.position="none"),
                        pe_dataset3_3g +guides(fill = FALSE) +theme(legend.position="none"),
                        pe_dataset4o_3g +theme(legend.position="none"),
                        align = 'vh',
                        nrow = 1
)

legend_1_to_3 <- get_legend(pe_dataset1_3g  +guides(fill = FALSE) +theme(legend.position = "bottom"))

perow_3g_partial <- perow_3g + draw_grob(legend_1_to_3, x = 0.35, y = -0.25, .3/3.3, 1)

legend_4 <- get_legend(pe_dataset4o_3g)

perow_3g_full <- plot_grid(perow_3g_partial, legend_4, rel_widths = c(3, .3)) 

# x11()
perow_3g_full

save_plot("./fig/plot_3G_ellipses.svg", perow_3g_full, dpi=500,
          ncol = 4, # we're saving a grid plot of 2 columns
          nrow = 2, # and 2 rows
          # each individual subplot should have an aspect ratio of 1.3
          base_aspect_ratio = 1
)

# ---- OU

# arrange the three plots in a single row, leaving space between plot B and C
perow_3g <- plot_grid( pe_dataset1_3g +guides(fill = FALSE) +theme(legend.position="none"),
                       pe_dataset2_3g +guides(fill = FALSE) +theme(legend.position="none"),
                       pe_dataset3_3g +guides(fill = FALSE) +theme(legend.position="none"),
                       NULL,
                       pe_dataset4o_3g +theme(legend.position="none"),
                   align = 'vh',
                   hjust = -1,
                   nrow = 1,
                   rel_widths = c(1, 1, 1, .3, 1)
)

legend_1_to_3 <- get_legend(pe_dataset1_3g +guides(fill = FALSE))

perow_3g_partial <- perow_3g + draw_grob(legend_1_to_3, 2.25/3.3, 0, .3/3.3, 1)

legend_4 <- get_legend(pe_dataset4o_3g + theme(legend.position = "bottom"))

perow_3g_full <- perow_3g_partial + draw_grob(legend_4, x = 0.5, 
                                                  y = -0.29, .3/3.3, 1)

# x11()
perow_3g_full


save_plot("C:/Users/beaklini/Desktop/P?s-Doc/Projeto_Rafael/Dicotomia/Arquivos_Allan/NEW_06-15_plot_3G_ellipses(alt2)(2).svg", perow_3g_full, dpi=500,
          ncol = 5, # we're saving a grid plot of 2 columns
          nrow = 2, # and 2 rows
          # each individual subplot should have an aspect ratio of 1.3
          base_aspect_ratio = 1
)


# ---- OU

# arrange the three plots in a single row, leaving space between plot B and C
perow_3g <- plot_grid( pe_dataset1_3g +guides(fill = FALSE),
                       pe_dataset2_3g +guides(fill = FALSE),
                       pe_dataset3_3g +guides(fill = FALSE),
                       NULL,
                       pe_dataset4o_3g,
                       align = 'vh',
                       hjust = -1,
                       nrow = 1,
                       rel_widths = c(1.4, 1.4, 1.4, .001)
)

# x11()
perow_3g

save_plot("C:/Users/beaklini/Desktop/P?s-Doc/Projeto_Rafael/Dicotomia/Arquivos_Allan/NEW_06-15_plot_3G_ellipses(alt3)(2).svg", perow_3g, dpi=500,
          ncol = 5, # we're saving a grid plot of 2 columns
          nrow = 2, # and 2 rows
          # each individual subplot should have an aspect ratio of 1.3
          base_aspect_ratio = 1
)

# --- OU
# A FAZER: para o que tinhamos antes, eh soh acrescentar guides(fill = TRUE)

perow_3g <- plot_grid( pe_dataset1_3g,
                       pe_dataset2_3g,
                       pe_dataset3_3g,
                       pe_dataset4o_3g,
                       align = 'vh',
                       hjust = -1,
                       nrow = 1
                       # rel_widths = c(1.4, 1.4, 1.4, .001)
)

# x11()
perow_3g

save_plot("C:/Users/beaklini/Desktop/P?s-Doc/Projeto_Rafael/Dicotomia/Arquivos_Allan/NEW_06-15_plot_3G_ellipses(alt4)(2).svg", perow_3g, dpi=500,
          ncol = 5, # we're saving a grid plot of 2 columns
          nrow = 2, # and 2 rows
          # each individual subplot should have an aspect ratio of 1.3
          base_aspect_ratio = 1
)




# ================ COMPLEMENTARY ANALYSIS - ICL / CONFUSION MATRICES / FREQUENCY ================ 

## ---------- CONFUSION MATRIX & FREQUENCIES ----------

## ::CONFUSION MATRIX - CLUSTER VS RATIO::

### dataset1
table(dataset1.df$Ratio, dataset1.df$Cluster)
table(dataset1.dfo$Ratio, dataset1.dfo$Cluster)

### dataset2
table(dataset2.df$Ratio, dataset2.df$Cluster)
table(dataset2.dfo$Ratio, dataset2.dfo$Cluster)

### dataset3
table(dataset3.df$Ratio, dataset3.df$Cluster)
table(dataset3.dfo$Ratio, dataset3.dfo$Cluster)

# dataset4 ---> no Ratio


## ::N BY EACH GROUP::

### dataset1
tab_cluster_dataset1 <- as.data.frame(table(dataset1.df$Cluster))
colnames(tab_cluster_dataset1)[1] <- "Cluster"
# removing outliers
tab_cluster_dataset1o <- as.data.frame(table(dataset1.dfo$Cluster))
colnames(tab_cluster_dataset1o)[1] <- "Cluster"

### dataset2
tab_cluster_dataset2 <- data.frame(table(dataset2.df$Cluster))
colnames(tab_cluster_dataset2)[1] <- "Cluster"
# removing outliers
tab_cluster_dataset2o <- data.frame(table(dataset2.dfo$Cluster))
colnames(tab_cluster_dataset2o)[1] <- "Cluster"

### dataset3
tab_cluster_dataset3 <- as.data.frame(table(dataset3.df$Cluster))
colnames(tab_cluster_dataset3)[1] <- "Cluster"
# removing outliers
tab_cluster_dataset3o <- as.data.frame(table(dataset3.dfo$Cluster))
colnames(tab_cluster_dataset3o)[1] <- "Cluster"

### dataset4
tab_cluster_dataset4 <- as.data.frame(table(dataset4.df$Cluster))
colnames(tab_cluster_dataset4)[1] <- "Cluster"
# removing outliers
tab_cluster_dataset4o <- as.data.frame(table(dataset4.dfo$Cluster))
colnames(tab_cluster_dataset4o)[1] <- "Cluster"


## :: R>1 & R < 1 FREQUENCY

### dataset1
R_dataset1<-as.data.frame(table(dataset1.df$Ratio))
colnames(R_dataset1)[1] <- "R"
# removing outliers
R_dataset1o<-as.data.frame(table(dataset1.dfo$Ratio))
colnames(R_dataset1o)[1] <- "R"

### dataset2
R_dataset2<-as.data.frame(table(dataset2.df$Ratio))
colnames(R_dataset2)[1] <- "R"
# removing outliers
R_dataset2o<-as.data.frame(table(dataset2.dfo$Ratio))
colnames(R_dataset2o)[1] <- "R"

### dataset3
R_dataset3<-as.data.frame(table(dataset3.df$Ratio))
colnames(R_dataset3)[1] <- "R"
# removing outliers
R_dataset3o<-as.data.frame(table(dataset3.dfo$Ratio))
colnames(R_dataset3o)[1] <- "R"

# dataset4 ---> no Ratio


## ---------- ICL FOR EACH GMM G=2 (KEEPING OUTLIERS) ----------

icl_df <- data.frame(ICL = c(icl(out_dataset1), icl(out_dataset2), icl(out_dataset3), icl(out_dataset4)))
rownames(icl_df) <- paste0("Dataset", 1:4)

## ---------- ICL FOR EACH GMM G=2 (REMOVING OUTLIERS) ----------

icl_dfo <- data.frame(ICL = c(icl(out_dataset1o), icl(out_dataset2o), icl(out_dataset3o), icl(out_dataset4o)))
rownames(icl_dfo) <- paste0("Dataset", 1:4, "o")


## ---------- ICL COMPARISON (ADDING & REMOVING VARIABLES)----------

## ::ALL 3X3 VARIABLE COMBINATIONS::

### structure
comb3x3_col = combn(ncol(dataset1.df[,1:4]),3)

nomes.dataset1 <- colnames(dataset1.df[,1:4])
nomes.dataset2 <- colnames(dataset2.df[,1:4])
nomes.dataset3 <- colnames(dataset3.df[,1:4])
nomes.dataset4 <- colnames(dataset4.df[,1:4])

### matrix to be filled
comb_nomes3x3 <- matrix(NA, nrow=3, ncol=ncol(comb3x3_col))

comb_nomes.dataset2_3x3 <- sapply(1:ncol(comb3x3_col),function(j){
  sapply(1:3,function(i){
    comb_nomes3x3[i,j]<-nomes.dataset2[comb3x3_col[i,j]]
  })
})
comb_nomes.dataset1_3x3 <- sapply(1:ncol(comb3x3_col),function(j){
  sapply(1:3,function(i){
    comb_nomes3x3[i,j]<-nomes.dataset1[comb3x3_col[i,j]]
  })
})
comb_nomes.dataset3_3x3 <- sapply(1:ncol(comb3x3_col),function(j){
  sapply(1:3,function(i){
    comb_nomes3x3[i,j]<-nomes.dataset3[comb3x3_col[i,j]]
  })
})
comb_nomes.dataset4_3x3 <- sapply(1:ncol(comb3x3_col),function(j){
  sapply(1:3,function(i){
    comb_nomes3x3[i,j]<-nomes.dataset4[comb3x3_col[i,j]]
  })
})

## ::GMM 3 x 3 COMBINATIONS::
library(mclust)

### dataset1
infl_out3x3_dataset1 <- apply(comb3x3_col, 2, function(x){
  set.seed(1984)
  out <- Mclust(dataset1.df[,c(x[1], x[2], x[3])], G=2)
  icl(out)
  #dataset2.df$cluster <- as.factor(out_dataset2$classification)
})
infl_out3x3_dataset1o <- apply(comb3x3_col, 2, function(x){
  set.seed(1984)
  out <- Mclust(dataset1.dfo[,c(x[1], x[2], x[3])], G=2)
  icl(out)
  #dataset2.df$cluster <- as.factor(out_dataset2$classification)
})

### dataset2
infl_out3x3_dataset2 <- apply(comb3x3_col, 2, function(x){
  set.seed(1984)
  out <- Mclust(dataset2.df[,c(x[1], x[2], x[3])], G=2)
  icl(out)
  #dataset2.df$cluster <- as.factor(out_dataset2$classification)
})
infl_out3x3_dataset2o <- apply(comb3x3_col, 2, function(x){
  set.seed(1984)
  out <- Mclust(dataset2.dfo[,c(x[1], x[2], x[3])], G=2)
  icl(out)
  #dataset2.df$cluster <- as.factor(out_dataset2$classification)
})

### dataset3
infl_out3x3_dataset3 <- apply(comb3x3_col, 2, function(x){
  set.seed(1984)
  out <- Mclust(dataset3.df[,c(x[1], x[2], x[3])], G=2)
  icl(out)
  #dataset2.df$cluster <- as.factor(out_dataset2$classification)
})
infl_out3x3_dataset3o <- apply(comb3x3_col, 2, function(x){
  set.seed(1984)
  out <- Mclust(dataset3.dfo[,c(x[1], x[2], x[3])], G=2)
  icl(out)
  #dataset2.df$cluster <- as.factor(out_dataset2$classification)
})

### dataset4
#infl_out3x3_dataset4 <- apply(comb3x3_col, 2, function(x){
#  set.seed(1984)
#  out <- Mclust(dataset4.df[,c(x[1], x[2], x[3])], G=2)
#  icl(out)
#  #dataset2.df$cluster <- as.factor(out_dataset2$classification)
#})
infl_out3x3_dataset4o <- apply(comb3x3_col, 2, function(x){
  set.seed(1984)
  out <- Mclust(dataset4.dfo[,c(x[1], x[2], x[3])], G=2)
  icl(out)
  #dataset2.df$cluster <- as.factor(out_dataset2$classification)
})

## ::ALL 4 VARIABLES::

### structure
comb4x4_col = combn(ncol(dataset1.df[,1:4]),4)

nomes.dataset1 <- colnames(dataset1.df[,1:4])
nomes.dataset2 <- colnames(dataset2.df[,1:4])
nomes.dataset3 <- colnames(dataset3.df[,1:4])
nomes.dataset4 <- colnames(dataset4.df[,1:4])

### matrix to be filled
comb_nomes4x4 <- matrix(NA, nrow=4, ncol=ncol(comb4x4_col))

comb_nomes.dataset2_4x4 <- sapply(1:ncol(comb4x4_col),function(j){
  sapply(1:4,function(i){
    comb_nomes4x4[i,j]<-nomes.dataset2[comb4x4_col[i,j]]
  })
})
comb_nomes.dataset1_4x4 <- sapply(1:ncol(comb4x4_col),function(j){
  sapply(1:4,function(i){
    comb_nomes4x4[i,j]<-nomes.dataset1[comb4x4_col[i,j]]
  })
})
comb_nomes.dataset3_4x4 <- sapply(1:ncol(comb4x4_col),function(j){
  sapply(1:4,function(i){
    comb_nomes4x4[i,j]<-nomes.dataset3[comb4x4_col[i,j]]
  })
})
comb_nomes.dataset4_4x4 <- sapply(1:ncol(comb4x4_col),function(j){
  sapply(1:4,function(i){
    comb_nomes4x4[i,j]<-nomes.dataset4[comb4x4_col[i,j]]
  })
})


## ::GMM FULL (4 VARIABLES)::
library(mclust)

### dataset1
infl_out4x4_dataset1 <- apply(comb4x4_col, 2, function(x){
  set.seed(1984)
  out <- Mclust(dataset1.df[,c(x[1], x[2], x[3], x[4])], G=2)
  icl(out)
  #dataset2.df$cluster <- as.factor(out_dataset2$classification)
})
infl_out4x4_dataset1o <- apply(comb4x4_col, 2, function(x){
  set.seed(1984)
  out <- Mclust(dataset1.dfo[,c(x[1], x[2], x[3], x[4])], G=2)
  icl(out)
  #dataset2.df$cluster <- as.factor(out_dataset2$classification)
})

### dataset2
infl_out4x4_dataset2 <- apply(comb4x4_col, 2, function(x){
  set.seed(1984)
  out <- Mclust(dataset2.df[,c(x[1], x[2], x[3], x[4])], G=2)
  icl(out)
  #dataset2.df$cluster <- as.factor(out_dataset2$classification)
})
infl_out4x4_dataset2o <- apply(comb4x4_col, 2, function(x){
  set.seed(1984)
  out <- Mclust(dataset2.dfo[,c(x[1], x[2], x[3], x[4])], G=2)
  icl(out)
  #dataset2.df$cluster <- as.factor(out_dataset2$classification)
})

### dataset3
infl_out4x4_dataset3 <- apply(comb4x4_col, 2, function(x){
  set.seed(1984)
  out <- Mclust(dataset3.df[,c(x[1], x[2], x[3], x[4])], G=2)
  icl(out)
  #dataset2.df$cluster <- as.factor(out_dataset2$classification)
})
infl_out4x4_dataset3o <- apply(comb4x4_col, 2, function(x){
  set.seed(1984)
  out <- Mclust(dataset3.dfo[,c(x[1], x[2], x[3], x[4])], G=2)
  icl(out)
  #dataset2.df$cluster <- as.factor(out_dataset2$classification)
})

### dataset4
infl_out4x4_dataset4 <- apply(comb4x4_col, 2, function(x){
  set.seed(1984)
  out <- Mclust(dataset4.df[,c(x[1], x[2], x[3], x[4])], G=2)
  icl(out)
  #dataset2.df$cluster <- as.factor(out_dataset2$classification)
})
infl_out4x4_dataset4o <- apply(comb4x4_col, 2, function(x){
  set.seed(1984)
  out <- Mclust(dataset4.dfo[,c(x[1], x[2], x[3], x[4])], G=2)
  icl(out)
  #dataset2.df$cluster <- as.factor(out_dataset2$classification)
})

## ::CREATING DATA.FRAMES WITH THE 3 X 3 COMBINATIONS AND FULL MODEL::

### dataset1
icl.dataset1 <- as.data.frame(c(signif(infl_out4x4_dataset1, 5), signif(infl_out3x3_dataset1, 5)))
rownames(icl.dataset1)[2:5] <- apply(comb_nomes.dataset1_3x3, 2, function(x) paste(x[1], x[2], x[3], sep=".vs.") )
rownames(icl.dataset1)[1] <- "Full"
colnames(icl.dataset1) <- "ICL"

icl.dataset1o <- as.data.frame(c(signif(infl_out4x4_dataset1o, 5), signif(infl_out3x3_dataset1o, 5)))
rownames(icl.dataset1o)[2:5] <- apply(comb_nomes.dataset1_3x3, 2, function(x) paste(x[1], x[2], x[3], sep=".vs.") )
rownames(icl.dataset1o)[1] <- "Full"
colnames(icl.dataset1o) <- "ICL"

### dataset2
icl.dataset2 <- as.data.frame(c(signif(infl_out4x4_dataset2, 5), signif(infl_out3x3_dataset2, 5)))
rownames(icl.dataset2)[2:5] <- apply(comb_nomes.dataset2_3x3, 2, function(x) paste(x[1], x[2], x[3], sep=".vs.") )
rownames(icl.dataset2)[1] <- "Full"
colnames(icl.dataset2) <- "ICL"

icl.dataset2o <- as.data.frame(c(signif(infl_out4x4_dataset2o, 5), signif(infl_out3x3_dataset2o, 5)))
rownames(icl.dataset2o)[2:5] <- apply(comb_nomes.dataset2_3x3, 2, function(x) paste(x[1], x[2], x[3], sep=".vs.") )
rownames(icl.dataset2o)[1] <- "Full"
colnames(icl.dataset2o) <- "ICL"

### dataset3
icl.dataset3 <- as.data.frame(c(signif(infl_out4x4_dataset3, 5), signif(infl_out3x3_dataset3, 5)))
rownames(icl.dataset3)[2:5] <- apply(comb_nomes.dataset3_3x3, 2, function(x) paste(x[1], x[2], x[3], sep=".vs.") )
rownames(icl.dataset3)[1] <- "Full"
colnames(icl.dataset3) <- "ICL"

icl.dataset3o <- as.data.frame(c(signif(infl_out4x4_dataset3o, 5), signif(infl_out3x3_dataset3o, 5)))
rownames(icl.dataset3o)[2:5] <- apply(comb_nomes.dataset3_3x3, 2, function(x) paste(x[1], x[2], x[3], sep=".vs.") )
rownames(icl.dataset3o)[1] <- "Full"
colnames(icl.dataset3o) <- "ICL"

### dataset4
#icl.dataset4 <- as.data.frame(c(signif(infl_out4x4_dataset4, 5), signif(infl_out3x3_dataset4, 5)))
#rownames(icl.dataset4)[2:5] <- apply(comb_nomes.dataset4_3x3, 2, function(x) paste(x[1], x[2], x[3], sep=".vs.") )
#rownames(icl.dataset4)[1] <- "Full"
#colnames(icl.dataset4) <- "ICL"

icl.dataset4o <- as.data.frame(c(signif(infl_out4x4_dataset4o, 5), signif(infl_out3x3_dataset4o, 5)))
rownames(icl.dataset4o)[2:5] <- apply(comb_nomes.dataset4_3x3, 2, function(x) paste(x[1], x[2], x[3], sep=".vs.") )
rownames(icl.dataset4o)[1] <- "Full"
colnames(icl.dataset4o) <- "ICL"


## ::PLOTS FOR ICL EVOLUTION:
library(ggplot2)

# solution to ggplot stop adjusting factors automatically
# sol em: https://groups.google.com/forum/#!topic/ggplot2/CpmvClYT3Hw
icl.dataset1$id.ordered <- factor(rownames(icl.dataset1), levels=rownames(icl.dataset1))
icl.dataset2$id.ordered <- factor(rownames(icl.dataset2), levels=rownames(icl.dataset2))
icl.dataset3$id.ordered <- factor(rownames(icl.dataset3), levels=rownames(icl.dataset3))
#icl.dataset4$id.ordered <- factor(rownames(icl.dataset4), levels=rownames(icl.dataset4))

### without outliers
icl.dataset1o$id.ordered <- factor(rownames(icl.dataset1o), levels=rownames(icl.dataset1o))
icl.dataset2o$id.ordered <- factor(rownames(icl.dataset2o), levels=rownames(icl.dataset2o))
icl.dataset3o$id.ordered <- factor(rownames(icl.dataset3o), levels=rownames(icl.dataset3o))
icl.dataset4o$id.ordered <- factor(rownames(icl.dataset4o), levels=rownames(icl.dataset4o))


### dataset1
### calculating % change
var_icl_dataset1 <- trunc( c( -(icl.dataset1[2,"ICL"] - icl.dataset1[1,"ICL"])/icl.dataset1[1,"ICL"],
                              -(icl.dataset1[3,"ICL"] - icl.dataset1[1,"ICL"])/icl.dataset1[1,"ICL"],
                              -(icl.dataset1[4,"ICL"] - icl.dataset1[1,"ICL"])/icl.dataset1[1,"ICL"],
                              -(icl.dataset1[5,"ICL"] - icl.dataset1[1,"ICL"])/icl.dataset1[1,"ICL"]) *10^3)/10^3
var_icl_dataset1 <- paste0(var_icl_dataset1*100,'%')

### plot
p_dataset1_icl_new <-
  icl.dataset1 %>%
  ggplot(aes(x = id.ordered, y = ICL)) +
  geom_point(size = 2) +
  geom_hline(aes(yintercept = ICL[1]), color = pltte[pos2], size = 2, alpha=0.5) +
  geom_segment(aes(xend = id.ordered, yend = ICL[1]),
               size = 1, color = "black", linetype = "dashed", alpha=0.5) +
  scale_x_discrete(name = "Variables in the GMM Model") +
  scale_y_continuous(name = "ICL")+
  theme_bw() +
  theme(panel.grid = element_blank())+
  ggtitle("Dataset 1")+
  theme(plot.title = element_text(hjust=0.5))+
  annotate("text", x=c(1.8, 2.8, 3.8, 4.8), y=c(-1400, -900, rep(-1400,2)),
           label=var_icl_dataset1)

### without outliers
var_icl_dataset1o <- trunc( c( -(icl.dataset1o[2,"ICL"] - icl.dataset1o[1,"ICL"])/icl.dataset1o[1,"ICL"],
                              -(icl.dataset1o[3,"ICL"] - icl.dataset1o[1,"ICL"])/icl.dataset1o[1,"ICL"],
                              -(icl.dataset1o[4,"ICL"] - icl.dataset1o[1,"ICL"])/icl.dataset1o[1,"ICL"],
                              -(icl.dataset1o[5,"ICL"] - icl.dataset1o[1,"ICL"])/icl.dataset1o[1,"ICL"]) *10^3)/10^3
var_icl_dataset1o <- paste0(var_icl_dataset1o*100,'%')

### plot
p_dataset1o_icl_new <-
  icl.dataset1o %>%
  ggplot(aes(x = id.ordered, y = ICL)) +
  geom_point(size = 2) +
  geom_hline(aes(yintercept = ICL[1]), color = pltte[pos2], size = 2, alpha=0.5) +
  geom_segment(aes(xend = id.ordered, yend = ICL[1]),
               size = 1, color = "black", linetype = "dashed", alpha=0.5) +
  scale_x_discrete(name = "Variables in the GMM Model") +
  scale_y_continuous(name = "ICL")+
  theme_bw() +
  theme(panel.grid = element_blank())+
  ggtitle("Dataset 1")+
  theme(plot.title = element_text(hjust=0.5))+
  annotate("text", x=c(1.8, 2.8, 3.8, 4.8), y=c(-900, -500, rep(-900,2)),
           label=var_icl_dataset1o)


### dataset2
### calculating % change
var_icl_dataset2 <- trunc( c( -(icl.dataset2[2,"ICL"] - icl.dataset2[1,"ICL"])/icl.dataset2[1,"ICL"],
                              -(icl.dataset2[3,"ICL"] - icl.dataset2[1,"ICL"])/icl.dataset2[1,"ICL"],
                              -(icl.dataset2[4,"ICL"] - icl.dataset2[1,"ICL"])/icl.dataset2[1,"ICL"],
                              -(icl.dataset2[5,"ICL"] - icl.dataset2[1,"ICL"])/icl.dataset2[1,"ICL"])*10^3)/10^3
var_icl_dataset2 <- paste0(var_icl_dataset2*100,'%')

### plot
p_dataset2_icl_new <- 
  icl.dataset2 %>%
  ggplot(aes(x = id.ordered, y = ICL)) +
  geom_point(size = 2) +
  geom_hline(aes(yintercept = ICL[1]), color = pltte[pos2], size = 2, alpha=0.5) +
  geom_segment(aes(xend = id.ordered, yend = ICL[1]),
               size = 1, color = "black", linetype = "dashed", alpha=0.5) +
  scale_x_discrete(name = "Variables in the GMM Model") +
  scale_y_continuous(name = "ICL")+
  theme_bw() +
  theme(panel.grid = element_blank())+
  ggtitle("Dataset 2")+
  theme(plot.title = element_text(hjust=0.5))+
  annotate("text", x=c(1.8, 2.8, 3.8, 4.8), y=c(-1400, -800, rep(-1400,2)),
           label=c(var_icl_dataset2))

### without outliers
var_icl_dataset2o <- trunc( c( -(icl.dataset2o[2,"ICL"] - icl.dataset2o[1,"ICL"])/icl.dataset2o[1,"ICL"],
                              -(icl.dataset2o[3,"ICL"] - icl.dataset2o[1,"ICL"])/icl.dataset2o[1,"ICL"],
                              -(icl.dataset2o[4,"ICL"] - icl.dataset2o[1,"ICL"])/icl.dataset2o[1,"ICL"],
                              -(icl.dataset2o[5,"ICL"] - icl.dataset2o[1,"ICL"])/icl.dataset2o[1,"ICL"])*10^3)/10^3
var_icl_dataset2o <- paste0(var_icl_dataset2o*100,'%')

### plot
p_dataset2o_icl_new <- 
  icl.dataset2o %>%
  ggplot(aes(x = id.ordered, y = ICL)) +
  geom_point(size = 2) +
  geom_hline(aes(yintercept = ICL[1]), color = pltte[pos2], size = 2, alpha=0.5) +
  geom_segment(aes(xend = id.ordered, yend = ICL[1]),
               size = 1, color = "black", linetype = "dashed", alpha=0.5) +
  scale_x_discrete(name = "Variables in the GMM Model") +
  scale_y_continuous(name = "ICL")+
  theme_bw() +
  theme(panel.grid = element_blank())+
  ggtitle("Dataset 2")+
  theme(plot.title = element_text(hjust=0.5))+
  annotate("text", x=c(1.8, 2.8, 3.8, 4.8), y=c(-900, -500, rep(-900,2)),
           label=c(var_icl_dataset2o))


### dataset3
### calculating % change
# here, the ICL for the full model is positive - so we don't need the negative sign
# changed for v20 --- now we need -
var_icl_dataset3 <- trunc( c( -(icl.dataset3[2,"ICL"] - icl.dataset3[1,"ICL"])/icl.dataset3[1,"ICL"],
                              -(icl.dataset3[3,"ICL"] - icl.dataset3[1,"ICL"])/icl.dataset3[1,"ICL"],
                              -(icl.dataset3[4,"ICL"] - icl.dataset3[1,"ICL"])/icl.dataset3[1,"ICL"],
                              -(icl.dataset3[5,"ICL"] - icl.dataset3[1,"ICL"])/icl.dataset3[1,"ICL"]) *10^3)/10^3
var_icl_dataset3 <- paste0(var_icl_dataset3*100,'%')

### plot
p_dataset3_icl_new <-
  icl.dataset3 %>%
  ggplot(aes(x = id.ordered, y = ICL)) +
  geom_point(size = 2) +
  geom_hline(aes(yintercept = ICL[1]), color = pltte[pos2], size = 2, alpha=0.5) +
  geom_segment(aes(xend = id.ordered, yend = ICL[1]),
               size = 1, color = "black", linetype = "dashed", alpha=0.5) +
  scale_x_discrete(name = "Variables in the GMM Model") +
  scale_y_continuous(name = "ICL")+
  theme_bw() +
  theme(panel.grid = element_blank())+
  ggtitle("Dataset 3")+
  theme(plot.title = element_text(hjust=0.5))+
  annotate("text", x=c(1.7, 2.7, 3.7, 4.7), y=c(-7500, -7600, -6000, -5500),
           label=var_icl_dataset3)

### without outliers
var_icl_dataset3o <- trunc( c(-(icl.dataset3o[2,"ICL"] - icl.dataset3o[1,"ICL"])/icl.dataset3o[1,"ICL"],
                              -(icl.dataset3o[3,"ICL"] - icl.dataset3o[1,"ICL"])/icl.dataset3o[1,"ICL"],
                              -(icl.dataset3o[4,"ICL"] - icl.dataset3o[1,"ICL"])/icl.dataset3o[1,"ICL"],
                              -(icl.dataset3o[5,"ICL"] - icl.dataset3o[1,"ICL"])/icl.dataset3o[1,"ICL"]) *10^3)/10^3
var_icl_dataset3o <- paste0(var_icl_dataset3o*100,'%')

### plot
p_dataset3o_icl_new <-
  icl.dataset3o %>%
  ggplot(aes(x = id.ordered, y = ICL)) +
  geom_point(size = 2) +
  geom_hline(aes(yintercept = ICL[1]), color = pltte[pos2], size = 2, alpha=0.5) +
  geom_segment(aes(xend = id.ordered, yend = ICL[1]),
               size = 1, color = "black", linetype = "dashed", alpha=0.5) +
  scale_x_discrete(name = "Variables in the GMM Model") +
  scale_y_continuous(name = "ICL")+
  theme_bw() +
  theme(panel.grid = element_blank())+
  ggtitle("Dataset 3")+
  theme(plot.title = element_text(hjust=0.5))+
  annotate("text", x=c(1.7, 2.7, 3.7, 4.7), y=c(-4500, -4400, -3800, -2800),
           label=var_icl_dataset3o)


### dataset4
### calculating % change
# here, the ICL for the full model is positive - so we don't need the negative sign
# changed for v20 --- now we need -
#var_icl_dataset4 <- trunc( c( -(icl.dataset4[2,"ICL"] - icl.dataset4[1,"ICL"])/icl.dataset4[1,"ICL"],
#                              -(icl.dataset4[3,"ICL"] - icl.dataset4[1,"ICL"])/icl.dataset4[1,"ICL"],
#                              -(icl.dataset4[4,"ICL"] - icl.dataset4[1,"ICL"])/icl.dataset4[1,"ICL"],
#                              -(icl.dataset4[5,"ICL"] - icl.dataset4[1,"ICL"])/icl.dataset4[1,"ICL"]) *10^3)/10^3
#var_icl_dataset4 <- paste0(var_icl_dataset4*100,'%')

#p_dataset4_icl_new <-
#  icl.dataset4 %>%
#  ggplot(aes(x = id.ordered, y = ICL)) +
#  geom_point(size = 2) +
#  geom_hline(aes(yintercept = ICL[1]), color = pltte[pos2], size = 2, alpha=0.5) +
#  geom_segment(aes(xend = id.ordered, yend = ICL[1]),
#               size = 1, color = "black", linetype = "dashed", alpha=0.5) +
#  scale_x_discrete(name = "Variables in the GMM Model") +
#  scale_y_continuous(name = "ICL")+
#  theme_bw() +
#  theme(panel.grid = element_blank())+
#  ggtitle("Dataset 4")+
#  theme(plot.title = element_text(hjust=0.5))+
#  annotate("text", x=c(1.7, 2.7, 3.7, 4.7), y=c(2000, -6000, -6000, -6000),
#           label=var_icl_dataset4)

### without outliers
var_icl_dataset4o <- trunc( c(-(icl.dataset4o[2,"ICL"] - icl.dataset4o[1,"ICL"])/icl.dataset4o[1,"ICL"],
                              -(icl.dataset4o[3,"ICL"] - icl.dataset4o[1,"ICL"])/icl.dataset4o[1,"ICL"],
                              -(icl.dataset4o[4,"ICL"] - icl.dataset4o[1,"ICL"])/icl.dataset4o[1,"ICL"],
                              -(icl.dataset4o[5,"ICL"] - icl.dataset4o[1,"ICL"])/icl.dataset4o[1,"ICL"]) *10^3)/10^3
var_icl_dataset4o <- paste0(var_icl_dataset4o*100,'%')

p_dataset4o_icl_new <-
  icl.dataset4o %>%
  ggplot(aes(x = id.ordered, y = ICL)) +
  geom_point(size = 2) +
  geom_hline(aes(yintercept = ICL[1]), color = pltte[pos2], size = 2, alpha=0.5) +
  geom_segment(aes(xend = id.ordered, yend = ICL[1]),
               size = 1, color = "black", linetype = "dashed", alpha=0.5) +
  scale_x_discrete(name = "Variables in the GMM Model") +
  scale_y_continuous(name = "ICL")+
  theme_bw() +
  theme(panel.grid = element_blank())+
  ggtitle("Dataset 4")+
  theme(plot.title = element_text(hjust=0.5))+
  annotate("text", x=c(1.7, 2.7, 3.7, 4.7), y=c(2000, -4000, -4000, -4000),
           label=var_icl_dataset4o) # pcts estao no automatico

p_dataset4_icl_new <-
  icl.dataset4o %>%
  ggplot(aes(x = id.ordered, y = ICL)) +
  geom_point(size = 2) +
  geom_hline(aes(yintercept = ICL[1]), color = pltte[pos2], size = 2, alpha=0.5) +
  geom_segment(aes(xend = id.ordered, yend = ICL[1]),
               size = 1, color = "black", linetype = "dashed", alpha=0.5) +
  scale_x_discrete(name = "Variables in the GMM Model") +
  scale_y_continuous(name = "ICL")+
  theme_bw() +
  theme(panel.grid = element_blank())+
  ggtitle("Dataset 4")+
  theme(plot.title = element_text(hjust=0.5))+
  annotate("text", x=c(1.7, 2.7, 3.7, 4.7), y=c(2000, -4000, -4000, -4000),
           label=var_icl_dataset4o) # pcts estao no automatico


## ::GRID PLOTS::
library(cowplot)

# arrange plots in one row
p_iclnew <- plot_grid( p_dataset1_icl_new,
                       p_dataset2_icl_new,
                       p_dataset3_icl_new,
                       p_dataset4_icl_new,
                       align = 'vh',
                       nrow = 2
)

# x11()
p_iclnew

save_plot("C:/Users/beaklini/Desktop/P?s-Doc/Projeto_Rafael/Dicotomia/Arquivos_Allan/NEW_06-15_plot_icl.svg", p_iclnew, dpi=500,
          ncol = 6, # we're saving a grid plot of 2 columns
          nrow = 2, # and 2 rows
          # each individual subplot should have an aspect ratio of 1.3
          base_aspect_ratio = 1
)

### without outliers
# arrange plots in one row
p_iclo_new <- plot_grid( p_dataset1o_icl_new,
                       p_dataset2o_icl_new,
                       p_dataset3o_icl_new,
                       p_dataset4o_icl_new,
                       align = 'vh',
                       nrow = 2,
                       labels = "Without Outliers"
)

# x11()
p_iclo_new

save_plot("C:/Users/beaklini/Desktop/P?s-Doc/Projeto_Rafael/Dicotomia/Arquivos_Allan/NEW_06-15_plot_iclo.svg", p_iclo_new, dpi=500,
          ncol = 6, # we're saving a grid plot of 2 columns
          nrow = 2, # and 2 rows
          # each individual subplot should have an aspect ratio of 1.3
          base_aspect_ratio = 1
)


## ---------- GMM WITH G=1 ----------

library(mclust)

### dataset1
set.seed(1984)
out_dataset1_1g <- Mclust(dataset1.df[,1:4], G=1)
icl1_1g <- icl(out_dataset1_1g)

set.seed(1984)
out_dataset1o_1g <- Mclust(dataset1.dfo[,1:4], G=1)
icl1o_1g <- icl(out_dataset1o_1g)

### dataset2
set.seed(1984)
out_dataset2_1g <- Mclust(dataset2.df[,1:4], G=1)
icl2_1g <- icl(out_dataset2_1g)

set.seed(1984)
out_dataset2o_1g <- Mclust(dataset2.dfo[,1:4], G=1)
icl2o_1g <- icl(out_dataset2o_1g)

### dataset3
set.seed(1984)
out_dataset3_1g <- Mclust(dataset3.df[,1:4], G=1)
icl3_1g <- icl(out_dataset3_1g)

set.seed(1984)
out_dataset3o_1g <- Mclust(dataset3.dfo[,1:4], G=1)
icl3o_1g <- icl(out_dataset3o_1g)

### dataset4
set.seed(1984)
out_dataset4_1g <- Mclust(dataset4.df[,1:4], G=1)
icl4_1g <- icl(out_dataset4_1g)

set.seed(1984)
out_dataset4o_1g <- Mclust(dataset4.dfo[,1:4], G=1)
icl4o_1g <- icl(out_dataset4o_1g)


icl_df_1g <- data.frame(rbind(icl1_1g, icl2_1g, icl3_1g, icl4_1g))
colnames(icl_df_1g) <- "ICL_G=1"
rownames(icl_df_1g) <- paste0("1G_Dataset", 1:4)


icl_dfo_1g <- data.frame(rbind(icl1o_1g, icl2o_1g, icl3o_1g, icl4o_1g))
colnames(icl_dfo_1g) <- "ICL_G=1"
rownames(icl_dfo_1g) <- paste0("1G_Dataset", 1:4, "o")


icl_df
icl_df_1g

icl_dfo
icl_dfo_1g

icl_df
icl_dfo

# results:

# 1) All ICLs for 2 groups are greater than for G=1 when keeping outliers
# 2) All ICLs for 2 groups are greater than for G=1 when removing outliers
# 3) Except for dataset4, all ICLs, when removing outliers, are dramatically better than when we keep them


## ---------- PROBABILITY TABLES AND CLASSIFICATION LABELS ---------- ##

## WITH OUTLIERS
#dataset1
write.table(dataset1.df, "C:/Users/beaklini/Desktop/P?s-Doc/Projeto_Rafael/Dicotomia/Arquivos_Allan/dataset1_clust&prob.txt", row.names = FALSE) 
#dataset2
write.table(dataset2.df, "C:/Users/beaklini/Desktop/P?s-Doc/Projeto_Rafael/Dicotomia/Arquivos_Allan/dataset2_clust&prob.txt", row.names = FALSE) 
#dataset3
write.table(dataset3.df, "C:/Users/beaklini/Desktop/P?s-Doc/Projeto_Rafael/Dicotomia/Arquivos_Allan/dataset3_clust&prob.txt", row.names = FALSE) 
#dataset4
write.table(dataset4.df, "C:/Users/beaklini/Desktop/P?s-Doc/Projeto_Rafael/Dicotomia/Arquivos_Allan/dataset4_clust&prob.txt", row.names = FALSE)

## WITHOUT OUTLIERS
#dataset1
write.table(dataset1.dfo, "C:/Users/beaklini/Desktop/P?s-Doc/Projeto_Rafael/Dicotomia/Arquivos_Allan/dataset1o_clust&prob.txt", row.names = FALSE) 
#dataset2
write.table(dataset2.dfo, "C:/Users/beaklini/Desktop/P?s-Doc/Projeto_Rafael/Dicotomia/Arquivos_Allan/dataset2o_clust&prob.txt", row.names = FALSE) 
#dataset3
write.table(dataset3.dfo, "C:/Users/beaklini/Desktop/P?s-Doc/Projeto_Rafael/Dicotomia/Arquivos_Allan/dataset3o_clust&prob.txt", row.names = FALSE) 
#dataset4
write.table(dataset4.dfo, "C:/Users/beaklini/Desktop/P?s-Doc/Projeto_Rafael/Dicotomia/Arquivos_Allan/dataset4o_clust&prob.txt", row.names = FALSE) 
    
